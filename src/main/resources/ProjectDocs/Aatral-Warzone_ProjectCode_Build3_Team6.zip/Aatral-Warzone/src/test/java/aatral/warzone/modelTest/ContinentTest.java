package aatral.warzone.modelTest;

import aatral.warzone.model.InputContinent;


/**
 * ContinentTest class is used to test the continent values of dependency map
 * @author Vignesh
 * @since 23.03.2021
 */

public class ContinentTest {
	
	/**
	 * continentTest method is used to test the create the new instance 
	 * for the continent object
	 */
	public void continentTest() {

		InputContinent l_ct = new InputContinent();

	}
}

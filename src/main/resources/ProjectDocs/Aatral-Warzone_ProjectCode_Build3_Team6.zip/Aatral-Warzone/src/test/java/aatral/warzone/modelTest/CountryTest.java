package aatral.warzone.modelTest;

import aatral.warzone.model.InputCountry;



/**
 * CountryTest class is used to test the country values of dependency map
 * @author Vignesh
 * @since 23.03.2021
 */

public class CountryTest {
	
	/**
	 * countryTest method is used to test the create the new instance 
	 * for the country object
	 */
	
	public void countryTest() {
		InputCountry l_co = new InputCountry();

	}
}

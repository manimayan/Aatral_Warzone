
public class Testresource {

}

package aatral.warzone.modelTest;

import aatral.warzone.model.InputBorders;
/**
 * BorderTest class is used to test the border values of dependency map
 * @author Vignesh
 * @since 23.03.2021
 */
public class BordersTest 
{
/**
 * bordersTest method is used to test the create the new instance 
 * for the border object
 */
	public void bordersTest() 
	{
		InputBorders l_br = new InputBorders();

	}

}

package aatral.warzone.statePattern;


/**
 * <h1>MapEditor</h1> This abstract class implements the state pattern for Mapeditor
 *
 * @author William
 * @version 1.0
 * @since 24-02-2021
 */
public abstract class MapEditor extends Phase{

}
